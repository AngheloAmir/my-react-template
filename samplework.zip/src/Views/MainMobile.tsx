/*
*/
import React from 'react';
import '../Styles/mainmobile.scss';
import AboutProfile from './UI/AboutProfile';

interface propsReceive {
    onClick: () => void;
}

//const sample = require('../Database/sample.json');
export default function MainMobile( props :propsReceive) {
    return (
        <div id='mobile-main'>
            <div id='navigation-bar'>
                this is the navigation bar
            </div>

            <div id='aboutinfo'>
                <AboutProfile onclick={props.onClick} />
            </div>

            <div id='content'>
                this contains the content
            </div>
        </div>
    )
}
