/*
*/
import React from 'react';
import '../Styles/maindesktop.scss';

import AboutProfile from './UI/AboutProfile';

interface propsReceive {
    onClick: () => void;
}

const sample = require('../Database/sample.json');
export default function MainDesktop( props :propsReceive) {
    return (
        <div id='desktop-main'>
            <div id='sidebar'>
                <AboutProfile   
                    onclick={props.onClick}
                />
            </div>

            <div id='content'>
                <div className='navigationbar'>
                    <h2>this is the navigation bar</h2>
                </div>

                <div className='displayedcontent'>
                    <h2>this is the content here</h2>
                </div>
            </div> 
        </div>
    )
} 
