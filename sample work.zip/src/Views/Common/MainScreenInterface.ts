/*
    Since the MainDesktop and MainMobile shares similar functionality and props,
    this file export an interface that is commong to them
*/

export interface MainScreenPropsReceive {
    onClick: () => void;
}
