/*
    Defines the available action type
*/

export enum ActionType {
    test,
    
}
